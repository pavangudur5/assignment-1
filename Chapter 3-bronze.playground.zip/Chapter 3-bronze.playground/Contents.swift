//: Playground - noun: a place where people can play

import Cocoa

var population: Int = 5000
var message: String

if population < 3000
{
    message = "\(population) is small town"
}
else if population >= 3000 && population < 4000
{
    message = "\(population) is a medium sized town"
}
else if population >= 4000 && population < 5000
{
    message = "\(population) is a big town!"
}
else
{
    message = "\(population) is a huge town!"
}
print(message)
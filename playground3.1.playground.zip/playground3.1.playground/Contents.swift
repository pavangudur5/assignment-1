//: Playground - noun: a place where people can play

import Cocoa
var population: Int = 5433
var message : String
if population < 1000{
    message = "\(population) is a small town"
} else {
    message = "\(population) is a pretty big"
}
print (message)

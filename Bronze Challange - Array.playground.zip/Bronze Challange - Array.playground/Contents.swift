//: Playground - noun: a place where people can play

import Cocoa

var toDoList = ["Take out garbage","Pay bills","Cross off finished items"]

if !toDoList.isEmpty && toDoList.count != 0{
    print("Array Contains Some values in it.")
}

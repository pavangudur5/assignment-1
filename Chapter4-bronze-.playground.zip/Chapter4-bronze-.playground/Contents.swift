//: Playground - noun: a place where people can play

import Cocoa

let number : Int = -1
//let unsigned : Uint8 = number

//: Playground - noun: a place where people can play

import Cocoa

let numberOfStoplights: Int = 4
var population: Int
population = 5422
let townName: String = "oklahoma"
var townUnemployment: Int = 1200
let townDescription = "\(townName) has a population of \(population) people with \(townUnemployment) of unemployees and \(numberOfStoplights) stoplights."
print(townDescription)

//: Playground - noun: a place where people can play

import Cocoa

var myFirstInt : Int = 0

for i in 1...5 {
    ++myFirstInt
    print(myFirstInt)
}

for case let i in 1...100 where i%3 == 0 {
    print(i)
}

for var i = 1; i < 6 ; i++
{
 ++myFirstInt
print(myFirstInt)
}


//while loop
 var k = 1
while k < 6{
    ++myFirstInt
    print(myFirstInt)
    ++k
}


var shield = 5
var blasterOverheating = false
var blasterFireount = 0
while shield > 0 {
    if blasterOverheating{
        print("blasrers are overheated")
        sleep(5)
        print ("blaster is ready to fire")
        sleep(1)
        blasterOverheating = false
        blasterFireount = 0
    }
    if blasterFireount > 100 {
        blasterOverheating = true
    continue
}
print("fire blaster!")
++blasterFireount
}



var shield1 = 5
var blasterOverheating1 = false
var blasterFireount1 = 0
var spacedemonsdestroyed = 0
while shield > 0 {
    if spacedemonsdestroyed == 500{
        print("you beat the game!")
        break
    }
    if blasterOverheating1{
        print("blasrers are overheated")
        sleep(5)
        print ("blaster is ready to fire")
        sleep(1)
        blasterOverheating1 = false
        blasterFireount1 = 0
    }
    if blasterFireount1 > 100 {
        blasterOverheating1 = true
        continue
    }
    print("fire blaster!")
    ++blasterFireount1
}


//: Playground - noun: a place where people can play

import Cocoa

var Str = "Hello, playground"

Str += "!"
print(Str)

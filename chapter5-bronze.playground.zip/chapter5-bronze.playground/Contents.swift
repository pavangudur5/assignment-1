//: Playground - noun: a place where people can play

import Cocoa
let point = (x:0 , y: 5)
switch point {
case let q1 where (point.x > 0) && (point.y > 0):
    print("\(q1) is in quadrant 1")
case let q1 where (point.x < 0) && (point.y > 0):
    print("\(q1) is in quadrant 2")
case let q1 where (point.x < 0) && (point.y < 0):
    print("\(q1) is in quadrant 3")
case let q1 where (point.x > 0) && (point.y < 0):
    print("\(q1) is in quadrant 4")
case (0,0):
    print("\(point) is at origin")
case (_,0):
    print("\(point) sits on the x-axis")
case (0,_):
    print("\(point) sits on the y-axis")
default:
    print("case not covered")
}
//: Playground - noun: a place where people can play


import Cocoa
for var i = 1; i <= 5; i++ {
    for var j = 0; j <= 100; j += 2 {
        print(j)
    }
    print ("\(i) time")
}

//: Playground - noun: a place where people can play

import Cocoa

//Implicitly Unwrapped Optionals
var errorCodeString: String!
errorCodeString = "404"
print(errorCodeString!.uppercaseString)


//: Playground - noun: a place where people can play

import Cocoa

let numberOfspotlights : Int = 4
var population: Int
population = 5422
let townName : String = "Knowhere"
let townDescription =
"\(townName) has a population of \(population) and \(numberOfspotlights) spotlights."
print(townDescription)


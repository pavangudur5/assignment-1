//: Playground - noun: a place where people can play

import Cocoa

var numberOfSpotlights = "Four"
//numberOfSpotlights += 2
// change in data type

var numberofspotlights: Int = 4
numberofspotlights += 2

print(numberofspotlights)
print(numberOfSpotlights)